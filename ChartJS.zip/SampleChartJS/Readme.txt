Sample for using Chart JS in Kalipso
This sample is linked into the local file Chart.min.js that is in "Files To Send" folder

To use in your own projects, simply put this file in the "Files To Send" folder of your project
Project website for documentation is: https://www.chartjs.org/