package com.sysdevmobile.idataplugin;

import android.app.Activity;
import android.content.Context;
import android.os.IScanListener;
import android.util.Log;
import android.view.KeyEvent;

import com.example.iscandemo.iScanInterface;
import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPIException;

import java.util.ArrayList;

public class ScanInterface extends KExternalEventsHandler implements KExternalScannerAPI, IScanListener {
    private KExternalEventsInterface mEventsInterface = null;
    private iScanInterface miScanInterface = null;
    private String onData;
    private int onType;
    private Object waiter = new Object();
    private boolean isScanAction;
    private boolean mEnabled=false;

    //************************ Implementation of Kalipso Barcode actions

    /**
     * Called to Connect to the barcode scanner
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param act             Current activity. It may be required by the implementation.
     * @param connectionType  The type of connection with the RFID device
     * @param address         The address of the RFID device.
     *                        For Bluetooth is the device MC address
     *                        For Socket is the IP or name
     *                        For Serial is the device string
     * @param userParameters  User parameters
     * @param eventsInterface Interface so you can trigger events in Kalipso.
     */
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalScannerAPIException {
        //Use this variable to send Barcode Scan events back to Kalipso
        //For example calling mEventsInterface.BarcodeScanned("barcodeString", barcodeType, "userParameter");
        mEventsInterface = eventsInterface;
        eventsInterface.AddOnAppEventListener(this);
        //Add your Barcode initialization code here
        miScanInterface = new iScanInterface(ctx);
        miScanInterface.registerScan(ScanInterface.this);

        miScanInterface.setOutputMode(1);
        miScanInterface.enablePlayBeep(true);
        miScanInterface.close();
        isScanAction=false;
        mEnabled=false;
    }

    /**
     * Called to disconnect from the barcode scanner
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalScannerAPIException {
        if(miScanInterface!=null) {
            miScanInterface.resetScan();
            miScanInterface.unregisterScan(this);
            miScanInterface.open();
            miScanInterface.setOutputMode(0);
            miScanInterface = null;
        }
        if(mEventsInterface!=null)
        {
            mEventsInterface.RemoveOnAppEventListener(this);
            mEventsInterface=null;
        }
    }

    /**
     * Called to enabled/disable the scanner
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param enabled        indicates to enable or disable the scanner
     * @param userParameters Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabled(Context ctx, boolean enabled, String userParameters) throws KExternalScannerAPIException {
        if (miScanInterface == null) {
            if (enabled) throw new KExternalScannerAPIException("Error enabling the scanner!\r\nNot connected to scanner");
            else throw new KExternalScannerAPIException("Error disabling the scanner!\r\nNot connected to scanner");
        }

        if (enabled) miScanInterface.open();
        else miScanInterface.close();
        mEnabled=enabled;
    }

    /**
     * Called to wait for a barcode scan. Add the results to the Lists of scannedBarcodes and types to the list of scannedBarcodeTypes
     *
     * @param ctx                 Current context. It may be required by the implementation.
     * @param timeOut             Maximum time in milliseconds to wait for the sacnner
     * @param softTrigger         If true, scanning will begin immediately by using a software trigger.
     *                            If false the user has to press the scan button to start scanning
     * @param scannedBarcodes     When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param scannedBarcodeTypes When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param userParameters      Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void ScanBarcode(Context ctx, int timeOut, boolean softTrigger, ArrayList<String> scannedBarcodes, ArrayList<String> scannedBarcodeTypes, String userParameters) throws KExternalScannerAPIException {
        if (miScanInterface == null) {
            throw new KExternalScannerAPIException("Not connected to scanner");
        }

        if(!mEnabled)
            miScanInterface.open();

        isScanAction = true;
        miScanInterface.setIntervalTime(timeOut);

        onData=null;
        onType=0;

        if (softTrigger) {
            if(!mEnabled)
            {
                try
                {
                    //Calling open() and scan_start() very quickly did not execute scan_start()
                    //Tested with 200ms and did not work
                    //Tested with 250ms and did work
                    //Use 300ms for safety
                    Thread.sleep(300);
                }
                catch (Exception e){}
            }
            miScanInterface.scan_start();
        }

        synchronized (waiter) {
            try {
                waiter.wait(timeOut); // unlocks myRunable while waiting

                if (softTrigger) miScanInterface.scan_stop();

                isScanAction = false;
                if(!mEnabled)
                    miScanInterface.close();

                if (onData != null && (!onData.isEmpty())) {
                    scannedBarcodes.add(onData);
                    scannedBarcodeTypes.add(String.valueOf(onType));

                    onData=null;
                    onType=0;
                } else {
                    throw new KExternalScannerAPIException("Scan timeout!");
                }
            } catch (InterruptedException e) {
                isScanAction = false;
                if(!mEnabled)
                    miScanInterface.close();
                if (softTrigger) miScanInterface.scan_stop();
                throw new KExternalScannerAPIException("Scan timeout!");
            }
        }
    }

    /**
     * Called to set the enabled symbologies
     *
     * @param ctx              Current context. It may be required by the implementation.
     * @param symbologiesList  list of symbologies to enable with Kalipso IDs. You will need to convert to the scanner IDs
     * @param symbologiesCount number of entries in symbologiesList array
     * @param userParameters   Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabledSymbologies(Context ctx, int[] symbologiesList, int symbologiesCount, String userParameters) throws KExternalScannerAPIException {
        if (miScanInterface == null) {
            throw new KExternalScannerAPIException("Not connected to scanner");
        }

        //Disable all
        int[] symlist = {0, 1, 2, 3, 4, 6, 8, 9, 10, 11, 12, 13, 15, 17, 19, 20, 48};
        for (int sym: symlist) {
            miScanInterface.setBarcodeEnable(sym, false);
        }

        for (int i : symbologiesList) {
            switch (i) {
                case 74:
                    miScanInterface.setBarcodeEnable(0, true);
                    break;
                case 19:
                    miScanInterface.setBarcodeEnable(1, true);
                    break;
                case 26:
                    miScanInterface.setBarcodeEnable(2, true);
                    break;
                case 23:
                    miScanInterface.setBarcodeEnable(3, true);
                    break;
                case 13:
                    miScanInterface.setBarcodeEnable(4, true);
                    break;
                case 25:
                    miScanInterface.setBarcodeEnable(6, true);
                    break;
                case 40:
                    miScanInterface.setBarcodeEnable(8, true);
                    break;
                case 2:
                    miScanInterface.setBarcodeEnable(9, true);
                    break;
                case 1:
                    miScanInterface.setBarcodeEnable(10, true);
                    break;
                case 15:
                    miScanInterface.setBarcodeEnable(11, true);
                    break;
                case 42:
                    miScanInterface.setBarcodeEnable(12, true);
                    break;
                case 36:
                    miScanInterface.setBarcodeEnable(13, true);
                    break;
                case 33:
                    miScanInterface.setBarcodeEnable(15, true);
                    break;
                case 41:
                    miScanInterface.setBarcodeEnable(17, true);
                    break;
                case 3:
                    miScanInterface.setBarcodeEnable(19, true);
                    break;
                case 4:
                    miScanInterface.setBarcodeEnable(20, true);
                    break;
                case -1:
                    miScanInterface.setBarcodeEnable(48, true);
                    break;
            }
        }
        if (miScanInterface == null)
            throw new KExternalScannerAPIException("Error enabling Symbologies");
    }
    //Called to get the enabled symbologies. They should be returned in symbologiesList[] and the function result should be the number of symbologies passed in symbologiesList[]

    /**
     * Called to get the enabled symbologies
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param symbologiesList When called this will be an empty list, on return should have the list of enabled symbologies with Kalipso IDs. You will need to convert from the scanner IDs
     * @param userParameters  Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void GetEnabledSymbologies(Context ctx, ArrayList<Integer> symbologiesList, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("iData SDK does not allow to retrieve scanner configuration");
    }

    //************************ Events reported from Kalipso through KExternalEventsHandler
    @Override
    public void onAppPaused(Context ctx) {
        if(miScanInterface!=null) {
            miScanInterface.setOutputMode(0);
            miScanInterface.unregisterScan(this);
        }
    }

    @Override
    public void onAppResumed(Context ctx) {
        if(miScanInterface!=null) {
            miScanInterface.registerScan(this);
            miScanInterface.setOutputMode(1);
        }
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event) {
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event) {
    }

    /**
     * @param data        Scanning data
     * @param type        barcode type
     * @param decodeTime  Scan time
     * @param keyDownTime The time when the key is pressed
     * @param imagePath   Image storage address (need to be turned on first to save images to be valid)
     */
    @Override
    public void onScanResults(String data, int type, long decodeTime, long keyDownTime, String imagePath) {
        //Log.d("KT1Data", data);
        //Log.d("KT1Type", String.valueOf(iData2Kal(type)));
        if (data != null && data.isEmpty() == false) {
            if (!isScanAction)
                mEventsInterface.BarcodeScanned(data, iData2Kal(type), "");
            else {
                onData = data;
                onType = iData2Kal(type);
                if(waiter!=null) {
                    synchronized (waiter) {
                        waiter.notify();
                    }
                }
            }
        }
    }

    private int iData2Kal(int codeType) {
        int res;
        switch (codeType) {
            case (int) 'b':
                res = 13;
                break;
            case (int) 'a':
                res = 19;
                break;
            case (int) 'j':
                res = 23;
                break;
            case (int) 'e':
                res = 15;
                break;
            case (int) 'i':
                res = 25;
                break;
            case (int) 'c':
                res = 3;
                break;
            case (int) 'E':
                res = 4;
                break;
            case (int) 'D':
                res = 2;
                break;
            case (int) 'd':
                res = 1;
                break;
            case (int) 'h':
                res = 26;
                break;
            case (int) 'r':
                res = 33;
                break;
            case (int) 'R':
                res = 36;
                break;
            case (int) 'w':
                res = 40;
                break;
            case (int) 's':
                res = 41;
                break;
            case (int) 'x':
                res = 42;
                break;
            case (int) 'z':
                res = 74;
                break;
            case (int) 'H':
                res = -1;
                break;
            case (int) 'I':
                res = 34;
                break;
            case (int) 'l':
                res = 28;
                break;
            case (int) 'F':
                res = 101;
                break;
            case (int) 'f':
                res = -2;
                break;
            case (int) 'm':
                res = 17;
                break;
            default:
                res = 0;
                break;
        }
        return res;
    }
}