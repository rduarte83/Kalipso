package com.sysdevmobile.idataplugin;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;

import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalRfidAPI;
import com.sysdevsolutions.external.kclientv50.KExternalRfidAPIException;
import com.sysdevsolutions.external.kclientv50.KExternalRfidTagInformation;
import com.uhf.base.UHFManager;
import com.uhf.base.UHFModuleType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.uhf.base.UHFModuleType.RM_MODULE;
import static com.uhf.base.UHFModuleType.SLR_MODULE;
import static com.uhf.base.UHFModuleType.UM_MODULE;

public class RFIDInterface extends KExternalEventsHandler implements KExternalRfidAPI {
    private KExternalEventsInterface mEventsInterface = null;
    private UHFManager uhfmanager;
    boolean ifInventory;
    private UHFModuleType moduleType;

    //************************ Implementation of Kalipso RFID actions

    /**
     * Called to Connect to the Rfid reader
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param act             Current activity. It may be required by the implementation.
     * @param connectionType  The type of connection with the RFID device
     * @param address         The address of the RFID device.
     *                        For Bluetooth is the device MC address
     *                        For Socket is the IP or name
     *                        For Serial is the device string
     * @param userParameters  User parameters
     * @param eventsInterface Interface so you can trigger events in Kalipso.
     */
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalRfidAPIException {
        //Use this variable to send RFID  back to Kalipso
        //For example calling mEventsInterface.RfidTagFound(tagData);
        mEventsInterface = eventsInterface;
        mEventsInterface.AddOnAppEventListener(this);
        //Add your RFID initialization code here
        switch (userParameters) {
            default:
            case "UM":
                moduleType = UM_MODULE;
                break;
            case "RM":
                moduleType = RM_MODULE;
                break;
            case "SLR":
                moduleType = SLR_MODULE;
                break;
        }
        uhfmanager = UHFManager.getUHFImplSigleInstance(moduleType, ctx);
        boolean status = uhfmanager.powerOn();
        if (!status) {
            throw new KExternalRfidAPIException("PowerOn failed");
        }
        SystemClock.sleep(3000);//Delay, power-on must be delayed

        if (moduleType == RM_MODULE)
            //After the RM module is powered on, it must first obtain the communication protocol, otherwise it cannot communicate.
            uhfmanager.getRFIDProtocolStandard();
    }

    /**
     * Called to disconnect from the Rfid reader
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalRfidAPIException {
        boolean status = uhfmanager.powerOff();
        if (!status) {
            throw new KExternalRfidAPIException("PowerOff failed!");
        }
    }

    /**
     * Called to check if a connection to a reader is available
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public int IsConnected(Context ctx, String userParameters) throws KExternalRfidAPIException {
        int status = uhfmanager.powerGet();
        if (status == -1) return 0;
        else return 1;
    }

    /**
     * Called to return the list of currently visible tags (like a quick inventory)
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param returnedMemoryBank The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     * @param returnStartAddress The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param returnLength       The length of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     * @return You should return a list filled with tags found
     */
    @Override
    public List<KExternalRfidTagInformation> GetTagList(Context ctx, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, MemoryBank returnedMemoryBank, int returnStartAddress, int returnLength, String userParameters) throws KExternalRfidAPIException {
        List<KExternalRfidTagInformation> tagList;
        tagList = inventoryAux(filterMemoryBank, filterMaskHexValue, filterBitIndex, filterBitLength, true, returnedMemoryBank, returnStartAddress, returnLength, false);
        Log.e("KT1Tag", tagList.toString());
        return tagList;
    }

    /**
     * Called to start an RFID inventory
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterDuplicates   True if you want duplicate tags to be filtered
     * @param returnedMemoryBank The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     * @param returnStartAddress The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param returnLength       The length of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     */
    @Override
    public void StartInventory(Context ctx, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, boolean filterDuplicates, MemoryBank returnedMemoryBank, int returnStartAddress, int returnLength, String userParameters) throws KExternalRfidAPIException {
        inventoryAux(filterMemoryBank, filterMaskHexValue, filterBitIndex, filterBitLength, filterDuplicates, returnedMemoryBank, returnStartAddress, returnLength, true);
    }

    /**
     * Called to stop an RFID inventory
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void StopInventory(Context ctx, String userParameters) throws KExternalRfidAPIException {
        boolean status = uhfmanager.stopInventory();
        ifInventory = false;//end inventory thread
        if (!status) throw new KExternalRfidAPIException("Stop Inventory Failed!");
    }

    /**
     * Called to read an RFID tag
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param memoryBank         The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     * @param startAddress       The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param length             The length of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param hexPassword        The password for tag access if necessary in hexadecimal
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation ReadTag(Context ctx, MemoryBank memoryBank, int startAddress, int length, String hexPassword, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException {
        KExternalRfidTagInformation kExternalRfidTagInformation = new KExternalRfidTagInformation();
        //RM module can only filter the parameters of bank, ptr and cnt in EPC area
        if (moduleType == RM_MODULE && filterMemoryBank != MemoryBank.EPC) {
            filterMemoryBank = MemoryBank.NONE;
            filterBitIndex = 0;
            filterBitLength = 0;
        }

        if (memoryBank == MemoryBank.EPCID) {
            startAddress = 4;
            length = 12;
        }

        String readTag = uhfmanager.readTag(hexPassword, bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue, bank2Int(memoryBank), startAddress / 2, length / 2);
        if (readTag == null) throw new KExternalRfidAPIException("Tag not found!");
        Log.e("KT1Tag", readTag);
        kExternalRfidTagInformation.tagID = readTag;
        return kExternalRfidTagInformation;
    }

    /**
     * Called to write an RFID tag
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param memoryBank         The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     * @param startAddress       The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param hexData            The data to write to the tag in hexadecimal
     * @param hexPassword        The password for tag access if necessary in hexadecimal
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation WriteTag(Context ctx, MemoryBank memoryBank, int startAddress, String hexData, String hexPassword, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException {
        int length = hexData.length();
        if (memoryBank == MemoryBank.EPCID) {
            startAddress = 4;
            length = 24;
        }
        Log.e("KT1DataLength", String.valueOf(length));

        //if you want to store more than 6 words of data in the EPC area, you can rewrite the PC field.
        if (length != 24 && memoryBank == MemoryBank.EPC) {
            //Calculation method of pc field: EPC length*2+4 the result is converted to hexadecimal
            String pcField = Integer.toHexString(length * 2 + 4);
            Log.e("KT1pcField", pcField);
            // less than 4 digits are filled with 0 at the end.
            while (pcField.length() < 4) pcField = pcField + "0";
            Log.e("KT1pcField", pcField);
            hexData = pcField + hexData;
            Log.e("KT1hexData", hexData);
            //the starting address is changed to 1, and the length is set to 4
            startAddress = 2;
        }

        //Use default password if empty: 00000000
        if (hexPassword.isEmpty()) hexPassword = "00000000";

        if (filterMemoryBank == MemoryBank.NONE) {
            filterBitIndex = 0;
            filterBitLength = 0;
            filterMaskHexValue = "0";
        }

        //RM module can only filter the parameters of bank, ptr and cnt in EPC area
        if (moduleType == RM_MODULE && memoryBank != MemoryBank.EPC) {
            filterMemoryBank = MemoryBank.NONE;
            filterBitIndex = 0;
            filterBitLength = 0;
        }
        Log.e("KT1WriteTagParam", "(" + hexPassword + "," + bank2Int(filterMemoryBank) + "," + filterBitIndex + "," + filterBitLength + "," + filterMaskHexValue + "," + bank2Int(memoryBank) + "," + startAddress / 2 + "," + length / 8 * 2 + "," + hexData + ")");

        boolean status = uhfmanager.writeTag(hexPassword, bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue, bank2Int(memoryBank), startAddress / 2, length / 8 * 2, hexData);
        if (!status) throw new KExternalRfidAPIException("Error writing Tag!");

        return new KExternalRfidTagInformation();
    }

    /**
     * Called to change a Tag password
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param currentPasswordHex The current password for tag access if necessary in hexadecimal
     * @param newPasswordHex     The new password for tag access in hexadecimal
     * @param newKillPasswordHex The new password for tag kill access in hexadecimal
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation SetTagPassword(Context ctx, String currentPasswordHex, String newPasswordHex, String newKillPasswordHex, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException {
        boolean status = false;

        if (!newPasswordHex.equals(""))
            status = uhfmanager.writeTag(currentPasswordHex, bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue, 0, 2, 2, newPasswordHex);
        if (!status) throw new KExternalRfidAPIException("Error changing access password!");
        if (!newKillPasswordHex.equals(""))
            status = uhfmanager.writeTag(currentPasswordHex, bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue, 0, 0, 2, newKillPasswordHex);
        if (!status) throw new KExternalRfidAPIException("Error changing kill password!");
        return new KExternalRfidTagInformation();
    }

    /**
     * Called to set the lock state of a Tag
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param lockZone           The password or memory bank to set the lock state
     * @param passwordHex        The password for tag access if necessary in hexadecimal
     * @param newLockState       The new lock state
     * @param newLockType        The new lock type
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation SetTagLockState(Context ctx, LockZone lockZone, String passwordHex, LockState newLockState, LockType newLockType, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException {
        int lockType = 0;
        boolean status = false;
        switch (newLockType) {
            case DontChange:
                break;
            case Open:
                lockType = 0;
                break;
            case Permanent:
                lockType = 1;
                break;
        }
        //RM module can only filter EPC area bank, ptr, cnt parameters are invalid
        if (moduleType == RM_MODULE) {
            filterMemoryBank = MemoryBank.EPC;
            filterBitIndex = 0;
            filterBitLength = 0;
        }
        switch (newLockState) {
            case DontChange:
                break;
            case Open:
                status = uhfmanager.unlockMen(passwordHex, bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue, lock2Int(lockZone), lockType);
                break;
            case Secured:
                status = uhfmanager.lockMen(passwordHex, bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue, lock2Int(lockZone), lockType);
                break;
        }
        if (!status) throw new KExternalRfidAPIException("Error setting Tag's lock state!");
        return new KExternalRfidTagInformation();
    }

    /**
     * Called to kill a tag
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param killPasswordHex    The kill password for the tag in hexadecimal
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation KillTag(Context ctx, String killPasswordHex, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException {
        //RM module can only filter EPC area bank, ptr, cnt parameters are invalid
        if (moduleType == RM_MODULE) {
            if (filterMemoryBank == MemoryBank.EPC) {
                filterBitIndex = 0;
                filterBitLength = 0;
            } else
                throw new KExternalRfidAPIException("RM module can only filter EPC area bank!");
        }
        boolean status = uhfmanager.killTag(killPasswordHex, bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue);
        if (!status) throw new KExternalRfidAPIException("Kill Tag Failed!");
        return new KExternalRfidTagInformation();
    }

    /**
     * Called to set a reader parameter
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param parameter      A string with the parameter to set
     * @param value          A string with the value to set. For numeric parameter, convert the string to the corresponding numeric type
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void SetReaderParameter(Context ctx, String parameter, String value, String userParameters) throws KExternalRfidAPIException {
        switch (parameter) {
            case "Session":
                switch (moduleType) {
                    case UM_MODULE:
                    case SLR_MODULE:
                        uhfmanager.sessionModeSet(Integer.parseInt(value));
                        break;
                    case RM_MODULE:
                        throw new KExternalRfidAPIException("Invalid module!\nSupported values: UM,SLR");
                }
                break;
            case "Mode":
                switch (moduleType) {
                    case UM_MODULE:
                        uhfmanager.inventoryModelSet(Integer.parseInt(value), false);
                        break;
                    case SLR_MODULE:
                        uhfmanager.slrInventoryModeSet(Integer.parseInt(value));
                        break;
                    case RM_MODULE:
                        throw new KExternalRfidAPIException("Invalid module!\nSupported modules: UM,SLR");
                }
                break;
            case "TxPower":
                uhfmanager.powerSet(Integer.parseInt(value));
                break;
            case "Region":
                uhfmanager.frequencyModeSet(Integer.parseInt(value));
                break;
            default:
                throw new KExternalRfidAPIException("Invalid parameter!\nSupported parameters: Session,Mode,TxPower,Region,");
        }
    }

    /**
     * Called to get a reader parameter
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param parameter      A string with the parameter to set
     * @param userParameters Generic parameters to use as you want.
     * @return String with value for the requested parameter. If it is a numerc value, convert to string to return to Kalipso
     */
    @Override
    public String GetReaderParameter(Context ctx, String parameter, String userParameters) throws KExternalRfidAPIException {
        int value;
        switch (parameter) {
            case "Session":
                switch (moduleType) {
                    case UM_MODULE:
                    case RM_MODULE:
                        value = uhfmanager.sessionModeGet();
                        break;
                    case SLR_MODULE:
                    default:
                        throw new KExternalRfidAPIException("Invalid module!\nSupported values: UM,SLR");
                }
                break;
            case "Mode":
                switch (moduleType) {
                    case UM_MODULE:
                        /*
                        0: multi-label mode
                        1: Fast mode
                        2: Low power consumption mode
                        3: Test mode
                        4: Power saving mode
                         */
                        value = uhfmanager.inventoryModelGet();
                        break;
                    case SLR_MODULE:
                        /*
                        0:S0,asynchronous inventory mode
                        (recommended for SLR5100 modules)
                        1: S1, asynchronous inventory mode (no module used for now)
                        2: Intelligent mode (recommended for other SLR modules)
                        3: Fast mode (recommended for E710 (SLR7100))
                        4: Normal mode (used by all SLR modules, suitable for reading single tags, in multi-tag scenarios, the performance is poor)
                         */
                        value = uhfmanager.slrInventoryModelGet();
                        break;
                    case RM_MODULE:
                    default:
                        throw new KExternalRfidAPIException("Invalid module!\nSupported values: UM,SLR");
                }
                break;
            case "TxPower":
                value = uhfmanager.powerGet();
                break;
            case "Region":
                /*
                0:China(840-845MHz)
                1:China(920-925MHz)
                2:Europe(865-868MHz)
                3:U.S.(902-928MHz)
                5:UM2 custom frequency point (note only UM2 module equipment supports）
                 */
                value = uhfmanager.frequencyModeGetNotFixedFreq();
                break;
            default:
                throw new KExternalRfidAPIException("Invalid parameter!\nSupported parameters: Session,Mode,TxPower,Region,Temp");
        }
        return String.valueOf(value);
    }

    /**
     * Called to send a command to the RFID reader
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param command        A string with the parameter to set
     * @param userParameters Generic parameters to use as you want.
     * @return String with the command response
     */
    @Override
    public String SendCommand(Context ctx, String command, String userParameters) throws KExternalRfidAPIException {
        throw new KExternalRfidAPIException("This SDK does not support sending commands!");
    }

    /**
     * Called to start a tag locating
     *
     * @param ctx                Current context. It may be required by the implementation.
     * @param filterMemoryBank   The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     * @param filterBitIndex     The index of the first bit to apply the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param filterBitLength    The length of the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     * @param userParameters     Generic parameters to use as you want.
     */
    @Override
    public void StartTagLocating(Context ctx, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException {
        throw new KExternalRfidAPIException("This SDK does not support Tag Locating!");
    }

    /**
     * Called to stop a tag locating
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void StopTagLocating(Context ctx, String userParameters) throws KExternalRfidAPIException {
        throw new KExternalRfidAPIException("This SDK does not support Tag Locating!");
    }

    //************************ Events reported from Kalipso through KExternalEventsHandler
    @Override
    public void onAppPaused(Context ctx) {
        uhfmanager.powerOff();
    }

    @Override
    public void onAppResumed(Context ctx) {
        uhfmanager.powerOn();
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event) {
        if (keyCode == 191) mEventsInterface.ScannerTriggerPressed();
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event) {
        if (keyCode == 191) mEventsInterface.ScannerTriggerReleased();
    }

    private int bank2Int(MemoryBank memoryBank) {
        int bank = 0;
        switch (memoryBank) {
            case NONE:
            case Reserved:
                bank = 0;
                break;
            case EPC:
            case EPCID:
                bank = 1;
                break;
            case TID:
            case EPCID_AND_TID:
                bank = 2;
                break;
            case USER:
            case EPCID_AND_USER:
                bank = 3;
                break;
        }
        return bank;
    }

    private int lock2Int(LockZone lockZone) {
        int lock = 0;
        switch (lockZone) {
            case KillPassword:
                lock = 0;
                break;
            case AccessPassword:
                lock = 1;
                break;
            case EPCMemoryBank:
                lock = 2;
                break;
            case USERMemoryBank:
                lock = 3;
                break;
        }
        return lock;
    }

    public List<KExternalRfidTagInformation> inventoryAux(MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, boolean filterDuplicates, MemoryBank returnedMemoryBank, int returnStartAddress, int returnLength, Boolean isStartInventory) throws KExternalRfidAPIException {
        boolean status = uhfmanager.stopInventory();
        if (!status) throw new KExternalRfidAPIException("Stop Inventory Failed!");
        ifInventory = false;
        boolean readTagModeSet;
        int intRetMemBank = 0;
        List<KExternalRfidTagInformation> inventoryList = new ArrayList<>();

        //Start address and Word Length(supported by UM module only)
        switch (returnedMemoryBank) {
            case EPCID:
                intRetMemBank = 0;
                returnStartAddress = 4;
                returnLength = 12;
                break;
            case EPC:
            case EPCID_AND_EPC:
                intRetMemBank = 0;
                break;
            case TID:
            case EPCID_AND_TID:
                intRetMemBank = 1;
                break;
            case EPCID_AND_USER:
            case USER:
                intRetMemBank = 2;
                break;
            case Reserved:
            case EPCID_AND_RESERVED:
                if (moduleType == UM_MODULE) intRetMemBank = 5;
                else
                    throw new KExternalRfidAPIException("This module does not support reading Reserved area!");
                break;
        }

        readTagModeSet = uhfmanager.readTagModeSet(intRetMemBank, returnStartAddress / 2, returnLength / 2, 0);
        if (!readTagModeSet)
            throw new KExternalRfidAPIException("Invalid return parameters!");

        //the RM module can only filter the EPC area temporarily and the first three parameters are invalid
        if (filterMemoryBank != MemoryBank.NONE) {
            //the RM module can only filter the EPC area temporarily and the first three parameters are invalid
            if (moduleType == RM_MODULE)
                status = uhfmanager.filterSet(1, 0, 0, filterMaskHexValue, 0);
            else
                status = uhfmanager.filterSet(bank2Int(filterMemoryBank), filterBitIndex, filterBitLength, filterMaskHexValue, 0);
            if (!status) throw new KExternalRfidAPIException("Invalid filter parameters!");
        }
        status = uhfmanager.startInventoryTag();
        if (!status) throw new KExternalRfidAPIException("Start Inventory Failed!");
        ifInventory = true;

        //Start the thread to receive tag data
        int finalReturnStartAddress = returnStartAddress;
        int finalReturnLength = returnLength;
        Runnable run = new Runnable() {
            @Override
            public void run() {
                while (ifInventory) {
                    String[] buf = uhfmanager.readTagFromBuffer();
                    KExternalRfidTagInformation kExternalRfidTagInformation = new KExternalRfidTagInformation();
                    if (buf != null) {
                    /* UM SLR module: String[0]:stores TID/User/Res data, if the inventory is read-only EPC, it is null | String[1]:EPC data | String[2]:RSSI data
                   RM module: String[0]:reserve, null | String[1]:EPC data | String[2]:7RSSI data | String[3]:temperature Fail：null */
                        Log.e("KT1buffer", Arrays.toString(buf));
                        switch (returnedMemoryBank) {
                            case NONE:
                            case EPCID:
                            case EPC:
                                kExternalRfidTagInformation.tagID = buf[1];
                                break;
                            case EPCID_AND_EPC:
                                kExternalRfidTagInformation.tagID = buf[1] + buf[1];
                                break;
                            case TID:
                                kExternalRfidTagInformation.tagID = buf[0].substring(finalReturnStartAddress / 2 * 4, finalReturnStartAddress / 2 * 4 + finalReturnLength / 2 * 4);
                                break;
                            case USER:
                            case Reserved:
                                kExternalRfidTagInformation.tagID = buf[0];
                                break;
                            case EPCID_AND_TID:
                                kExternalRfidTagInformation.tagID = buf[1] + buf[0].substring(finalReturnStartAddress / 2 * 4, finalReturnStartAddress / 2 * 4 + finalReturnLength / 2 * 4);
                                break;
                            case EPCID_AND_USER:
                            case EPCID_AND_RESERVED:
                                kExternalRfidTagInformation.tagID = buf[1] + buf[0];
                                break;
                        }
                        if (buf[2] != null && buf[2].length() > 0) {
                            kExternalRfidTagInformation.rssi = (short) Integer.parseInt(buf[2], 16);
                            kExternalRfidTagInformation.rssi = kExternalRfidTagInformation.rssi / 10.0;
                            //Log.e("KT1rssi", String.valueOf(kExternalRfidTagInformation.rssi));
                        }

                        if (filterDuplicates) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                if (inventoryList.stream().anyMatch(x -> x.tagID.equals(kExternalRfidTagInformation.tagID))) {
                                } else {
                                    inventoryList.add(kExternalRfidTagInformation);
                                    if (isStartInventory)
                                        mEventsInterface.RfidTagFound(kExternalRfidTagInformation);
                                }
                            }
                        } else {
                            inventoryList.add(kExternalRfidTagInformation);
                            if (isStartInventory)
                                mEventsInterface.RfidTagFound(kExternalRfidTagInformation);
                        }
                    }
                }
            }
        };

        Thread t = new Thread(run);
        t.start();

        if (!isStartInventory) {
            try {
                t.join(3000);
                ifInventory = false;
                uhfmanager.stopInventory();
            } catch (InterruptedException e) {
                throw new KExternalRfidAPIException("Error:" + e);
            }
            if (t.isAlive()) t.interrupt();
            String tagList = "";
            for (KExternalRfidTagInformation tag : inventoryList) {
                tagList = tagList + "," + tag;
            }
            Log.e("KT1InventoryList", tagList);
        }
        return inventoryList;
    }
}