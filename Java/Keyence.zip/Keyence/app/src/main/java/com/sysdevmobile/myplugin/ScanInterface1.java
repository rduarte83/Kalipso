package com.sysdevmobile.myplugin;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.KeyEvent;
import com.keyence.autoid.sdk.SdkStatus;
import com.keyence.autoid.sdk.scan.ScanManager;
import com.keyence.autoid.sdk.scan.DecodeResult;
import com.keyence.autoid.sdk.scan.scanparams.CodeType;
import com.keyence.autoid.sdk.scan.scanparams.DataOutput;
import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPIException;

import java.util.ArrayList;

public class ScanInterface1 extends KExternalEventsHandler implements KExternalScannerAPI, ScanManager.DataListener {
    private KExternalEventsInterface mEventsInterface = null;
    private Activity mAct = null;
    private ScanManager mScanManager = null;
    private final DataOutput dataOutput = new DataOutput();
    private String onType = "";
    private String onData = "";

    //************************ Implementation of Kalipso Barcode actions

    /**
     * Called to Connect to the barcode scanner
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param act             Current activity. It may be required by the implementation.
     * @param connectionType  The type of connection with the RFID device
     * @param address         The address of the RFID device.
     *                        For Bluetooth is the device MC address
     *                        For Socket is the IP or name
     *                        For Serial is the device string
     * @param userParameters  User parameters
     * @param eventsInterface Interface so you can trigger events in Kalipso.
     */
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalScannerAPIException {
        //Use this variable to send Barcode Scan events back to Kalipso
        //For example calling mEventsInterface.BarcodeScanned("barcodeString", barcodeType, "userParameter");
        mEventsInterface = eventsInterface;
        mAct = act;
        eventsInterface.AddOnAppEventListener(this);

        Object waiter = new Object();

        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //Add your Barcode initialization code here
                mScanManager = ScanManager.createScanManager(ctx);
                mScanManager.getConfig(dataOutput);
                boolean wedge = dataOutput.keyStrokeOutput.enabled;
                Log.d("KT1WedgeGET", String.valueOf(wedge));
                dataOutput.keyStrokeOutput.enabled = false;
                mScanManager.setConfig(dataOutput);
                mScanManager.addDataListener(ScanInterface1.this);
                synchronized(waiter)
                {
                    waiter.notify();
                }
            }
        });

        synchronized( waiter ) {
            try {
                waiter.wait() ; // unlocks myRunable while waiting
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        if(mScanManager==null) {
            throw new KExternalScannerAPIException("Unable to Connect to the barcode scanner. NULL was returned.");
        }
    }

    /**
     * Called to disconnect from the barcode scanner
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalScannerAPIException {
        mScanManager.removeDataListener(this);
        mScanManager.releaseScanManager();

        if(mScanManager==null) {
            throw new KExternalScannerAPIException("Unable to Disconnect from from the barcode scanner. NULL was returned.");
        }
    }


    /**
     * Called to enabled/disable the scanner
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param enabled        indicates to enable or disable the scanner
     * @param userParameters Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabled(Context ctx, boolean enabled, String userParameters) throws KExternalScannerAPIException {
        if (enabled) {
            mScanManager.unlockScanner();
        } else {
            mScanManager.lockScanner();
        }

        if(mScanManager==null) {
            throw new KExternalScannerAPIException("Unable to Enable the scanner. NULL was returned.");
        }
    }


    /**
     * Called to wait for a barcode scan. Add the results to the Lists of scannedBarcodes and types to the list of scannedBarcodeTypes
     *
     * @param ctx                 Current context. It may be required by the implementation.
     * @param timeOut             Maximum time in milliseconds to wait for the sacnner
     * @param softTrigger         If true, scanning will begin immediately by using a software trigger.
     *                            If false the user has to press the scan button to start scanning
     * @param scannedBarcodes     When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param scannedBarcodeTypes When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param userParameters      Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void ScanBarcode(Context ctx, int timeOut, boolean softTrigger, ArrayList<String> scannedBarcodes, ArrayList<String> scannedBarcodeTypes, String userParameters) throws KExternalScannerAPIException {

        Object waiter = new Object();

        mAct.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Start reading.
                mScanManager.startRead();
                // Acquire the reading status.
                    mScanManager.addDataListener(ScanInterface1.this::onDataReceived);
                    Log.d("KT1Data", onData);
                    Log.d("KT1Type", onType);
                    scannedBarcodes.add(onData);
                    scannedBarcodeTypes.add(onType);
                    // Stop reading.
                    mScanManager.stopRead();
                    mScanManager.removeDataListener(ScanInterface1.this);

                synchronized(waiter)
                {
                    waiter.notify();
                }
            }
        });

        synchronized( waiter ) {
            try {
                waiter.wait() ; // unlocks myRunable while waiting
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }


    /**
     * Called to set the enabled symbologies
     *
     * @param ctx              Current context. It may be required by the implementation.
     * @param symbologiesList  list of symbologies to enable with Kalipso IDs. You will need to convert to the scanner IDs
     * @param symbologiesCount number of entries in symbologiesList array
     * @param userParameters   Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabledSymbologies(Context ctx, int[] symbologiesList, int symbologiesCount, String userParameters) throws KExternalScannerAPIException {




        throw new KExternalScannerAPIException("Not implemented");
    }


    //Called to get the enabled symbologies. They should be returned in symbologiesList[] and the function result should be the number of symbologies passed in symbologiesList[]

    /**
     * Called to get the enabled symbologies
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param symbologiesList When called this will be an empty list, on return should have the list of enabled symbologies with Kalipso IDs. You will need to convert from the scanner IDs
     * @param userParameters  Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void GetEnabledSymbologies(Context ctx, ArrayList<Integer> symbologiesList, String userParameters) throws KExternalScannerAPIException {
        // Define a variable to store the code type.
        CodeType codeType = new CodeType();
        // Acquire the current setting values.
        SdkStatus status = mScanManager.getConfig(codeType);

        if (status == SdkStatus.SUCCESS){
            if (codeType.upcEanJan) symbologiesList.add(codeNr("UPC/EAN/JAN"));
            if (codeType.code128) symbologiesList.add(codeNr("Code128"));
            if (codeType.code39) symbologiesList.add(codeNr("Code39"));
            if (codeType.itf) symbologiesList.add(codeNr("ITF"));
            if (codeType.gs1DataBar) symbologiesList.add(codeNr("GS1 DataBar"));
            if (codeType.datamatrix) symbologiesList.add(codeNr("Datamatrix"));
            if (codeType.qrCode) symbologiesList.add(codeNr("QRCode"));
            if (codeType.pdf417) symbologiesList.add(codeNr("PDF417"));
            if (codeType.industrial2Of5) symbologiesList.add(codeNr("Industrial 2of5"));
            if (codeType.codabarNw7) symbologiesList.add(codeNr("Codabar(NW7)"));
            if (codeType.coop2Of5) symbologiesList.add(codeNr("COOP2of5"));
            if (codeType.code93) symbologiesList.add(codeNr("Code93"));
            if (codeType.compositeAb_Gs1Databar) symbologiesList.add(codeNr("Composite AB(GS1-Databar"));
            if (codeType.compositeAb_EanUpc) symbologiesList.add(codeNr("Composite AB(EAN/UPC)"));
            if (codeType.composite_Gs1_128) symbologiesList.add(codeNr("Composite (GS1-128)"));
            if (codeType.postal) symbologiesList.add(codeNr("Postal"));
            if (codeType.ocr) symbologiesList.add(codeNr("Ocr"));
            Log.d("KT1codeType", symbologiesList.toString());
        } else {
            throw new KExternalScannerAPIException("Unable to Get Symbologies. Error:" + status);
        }
    }


    //************************ Events reported from Kalipso through KExternalEventsHandler
    @Override
    public void onAppPaused(Context ctx) {
        super.onAppPaused(ctx);
        mScanManager.lockScanner();
        mScanManager.removeDataListener(this);
        Log.d("KT1Paused", "AppPaused");

    }

    @Override
    public void onAppResumed(Context ctx) {
        super.onAppResumed(ctx);
        mScanManager.unlockScanner();
        mScanManager.addDataListener(this);
        Log.d("KT1Resumed", "AppResumed");
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event) {
        Log.d("KT1KeyEventD", String.valueOf(keyCode));
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event) {
        Log.d("KT1KeyEventU", String.valueOf(keyCode));
    }

    // Create a read event
    @Override
    public void onDataReceived(DecodeResult decodeResult) {
        // Acquire the reading result.
        DecodeResult.Result result = decodeResult.getResult();

        if (result == DecodeResult.Result.SUCCESS) {
            Log.d("KT1Result", String.valueOf(result));
            // Acquire the read code type.
            String codeType = decodeResult.getCodeType();
            onType = codeType;
            Log.d("KT1codeType", codeType);
            // Acquire the read data.
            String data = decodeResult.getData();
            onData = data;
            Log.d("KT1data", data);
            mEventsInterface.BarcodeScanned(data, codeNr(codeType), "");
        }
    }
    private int codeNr(String codeType) {
        int res;
        switch (codeType) {
            case "UPC/EAN/JAN":
                res = 1;
                break;
            case "Code128":
                res = 23;
                break;
            case "Code39":
                res = 13;
                break;
            case "ITF":
                res = 15;
                break;
            case "GS1 DataBar":
                res = 37;
                break;
            case "Datamatrix":
                res = 40;
                break;
            case "QRCode":
                res = 41;
                break;
            case "PDF417":
                res = 33;
                break;
            case "Industrial 2of5":
                res = 101;
                break;
            case "Codabar(NW7)":
                res = 19;
                break;
            case "COOP2of5":
                res = -1;
                break;
            case "Code93":
                res = 25;
                break;
            case "Composite AB(GS1-Databar)":
                res = 43;
                break;
            case "Composite AB(EAN/UPC)":
                res = 47;
                break;
            case "Composite (GS1-128)":
                res = 46;
                break;
            case "Postal":
                res = 66;
                break;
            case "Ocr":
                res = -2;
                break;
            default:
                res = 0;
                break;
        }
        return res;
    }
}
