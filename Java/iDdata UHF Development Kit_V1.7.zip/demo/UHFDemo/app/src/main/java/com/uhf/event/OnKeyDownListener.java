package com.uhf.event;

import android.view.KeyEvent;

/**
 * Author CYD
 * Date 2019/2/20
 *
 */
public interface OnKeyDownListener {
    void onKeyDown(int keyCode, KeyEvent event);
}
