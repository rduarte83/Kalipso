package com.sysdevmobile.chainwayplugin;

import android.app.Activity;
import android.content.Context;
import android.view.KeyEvent;

import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalRfidAPI;
import com.sysdevsolutions.external.kclientv50.KExternalRfidAPIException;
import com.sysdevsolutions.external.kclientv50.KExternalRfidTagInformation;

import java.util.List;

public class RFIDInterface extends KExternalEventsHandler implements KExternalRfidAPI {
    private KExternalEventsInterface mEventsInterface = null;

    //************************ Implementation of Kalipso RFID actions

    /**
     * Called to Connect to the Rfid reader
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param act Current activity. It may be required by the implementation.
     *
     * @param connectionType The type of connection with the RFID device
     *
     * @param address The address of the RFID device.
     *                For Bluetooth is the device MC address
     *                For Socket is the IP or name
     *                For Serial is the device string
     *
     * @param userParameters User parameters
     *
     * @param eventsInterface Interface so you can trigger events in Kalipso.
     */
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalRfidAPIException
    {
        //Use this variable to send RFID  back to Kalipso
        //For example calling mEventsInterface.RfidTagFound(tagData);
        mEventsInterface=eventsInterface;
        eventsInterface.AddOnAppEventListener(this);

        //Add your RFID initialization code here
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to disconnect from the Rfid reader
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to check if a connection to a reader is available
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return Should return 0 for false or 1 for true
     *          but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public int IsConnected(Context ctx, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to return the list of currently visible tags (like a quick inventory)
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param returnedMemoryBank The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     * @param returnStartAddress The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param returnLength The length of the return for the specified memory bank
     *                     If a memory bank is NONE or EPCID, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return You should return a list filled with tags found
     */
    @Override
    public List<KExternalRfidTagInformation> GetTagList(Context ctx, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, MemoryBank returnedMemoryBank, int returnStartAddress, int returnLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to start an RFID inventory
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterDuplicates True if you want duplicate tags to be filtered
     *
     * @param returnedMemoryBank The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     * @param returnStartAddress The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param returnLength The length of the return for the specified memory bank
     *                     If a memory bank is NONE or EPCID, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void StartInventory(Context ctx, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, boolean filterDuplicates, MemoryBank returnedMemoryBank, int returnStartAddress, int returnLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to stop an RFID inventory
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void StopInventory(Context ctx, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }



    /**
     * Called to read an RFID tag
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param memoryBank The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     *
     * @param startAddress The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param length The length of the return for the specified memory bank
     *                     If a memory bank is NONE or EPCID, this parameter is ignored.
     *
     * @param hexPassword   The password for tag access if necessary in hexadecimal
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation ReadTag(Context ctx, MemoryBank memoryBank, int startAddress, int length, String hexPassword, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to write an RFID tag
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param memoryBank The memory bank to be returned . If NONE is specified the default should be used, usually the EPCID
     *
     * @param startAddress The start address of the return for the specified memory bank
     *                           If a memory bank is NONE or EPCID, this parameter is ignored.
     * @param hexData The data to write to the tag in hexadecimal
     *
     * @param hexPassword   The password for tag access if necessary in hexadecimal
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation WriteTag(Context ctx, MemoryBank memoryBank, int startAddress, String hexData, String hexPassword, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to change a Tag password
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param currentPasswordHex The current password for tag access if necessary in hexadecimal
     *
     * @param newPasswordHex The new password for tag access in hexadecimal
     *
     * @param newKillPasswordHex The new password for tag kill access in hexadecimal
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation SetTagPassword(Context ctx, String currentPasswordHex, String newPasswordHex, String newKillPasswordHex, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to set the lock state of a Tag
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param lockZone The password or memory bank to set the lock state
     *
     * @param passwordHex The password for tag access if necessary in hexadecimal
     *
     * @param newLockState The new lock state
     *
     * @param newLockType The new lock type
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation SetTagLockState(Context ctx, LockZone lockZone, String passwordHex, LockState newLockState, LockType newLockType, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to kill a tag
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param killPasswordHex The kill password for the tag in hexadecimal
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return You can optionally return the tag information with any required values
     */
    @Override
    public KExternalRfidTagInformation KillTag(Context ctx, String killPasswordHex, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to set a reader parameter
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param parameter A string with the parameter to set
     *
     * @param value A string with the value to set. For numeric parameter, convert the string to the corresponding numeric type
     *
     * @param userParameters Generic parameters to use as you want.
     *
     */
    @Override
    public void SetReaderParameter(Context ctx, String parameter, String value, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to get a reader parameter
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param parameter A string with the parameter to set
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return String with value for the requested parameter. If it is a numerc value, convert to string to return to Kalipso
     */
    @Override
    public String GetReaderParameter(Context ctx, String parameter, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to send a command to the RFID reader
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param command A string with the parameter to set
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return String with the command response
     */
    @Override
    public String SendCommand(Context ctx, String command, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to start a tag locating
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param filterMemoryBank The memory bank to perform the filter, it can be NONE if no filter is to be applied.
     *
     * @param filterMaskHexValue Hexadecimal value fo the mask to use for the filter.
     *                           If filterMemoryBank is NONE, this parameter is ignored.
     *                           EPCID is to filter by the EPCID value and not the memory bank itself. EPCID starts at byte 4.
     *
     * @param filterBitIndex The index of the first bit to apply the filter.
     *                       If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param filterBitLength The length of the filter.
     *                        If filterMemoryBank is NONE, this parameter is ignored.
     *
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void StartTagLocating(Context ctx, MemoryBank filterMemoryBank, String filterMaskHexValue, int filterBitIndex, int filterBitLength, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }


    /**
     * Called to stop a tag locating
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param userParameters Generic parameters to use as you want.
     *
     */
    @Override
    public void StopTagLocating(Context ctx, String userParameters) throws KExternalRfidAPIException
    {
        throw new KExternalRfidAPIException("Not implemented");
    }




    //************************ Events reported from Kalipso through KExternalEventsHandler
    @Override
    public void onAppPaused(Context ctx)
    {
    }

    @Override
    public void onAppResumed(Context ctx)
    {
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event)
    {
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event)
    {
    }
}
