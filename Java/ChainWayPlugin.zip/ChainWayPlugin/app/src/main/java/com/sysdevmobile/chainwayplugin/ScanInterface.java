package com.sysdevmobile.chainwayplugin;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;

import com.rscja.deviceapi.BluetoothReader;
import com.rscja.deviceapi.interfaces.ConnectionStatus;
import com.rscja.deviceapi.interfaces.ConnectionStatusCallback;
import com.rscja.deviceapi.interfaces.KeyEventCallback;
import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPIException;

import java.util.ArrayList;

public class ScanInterface extends KExternalEventsHandler implements KExternalScannerAPI {
    private Activity act;
    private KExternalEventsInterface mEventsInterface = null;
    private BluetoothReader btReader = BluetoothReader.getInstance();
    private BTStatus btStatus = new BTStatus();
    private BluetoothDevice btDevice;
    private ArrayList<String> scannedBarcodes, scannedBarcodeTypes;
    private Object waiter = new Object();
    private String macAddress, data;
    private Boolean isRunning = false, isTrigger = true, isEnabled = false, isEvent = true;
    private static final int ALL_FILES_ACCESS_PERMISSION = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    private static final int REQUEST_ACTION_LOCATION_SETTINGS = 3;


    //************************ Implementation of Kalipso Barcode actions

    /**
     * Called to Connect to the barcode scanner
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param act             Current activity. It may be required by the implementation.
     * @param connectionType  The type of connection with the RFID device
     * @param address         The address of the RFID device.
     *                        For Bluetooth is the device MC address
     *                        For Socket is the IP or name
     *                        For Serial is the device string
     * @param userParameters  User parameters
     * @param eventsInterface Interface so you can trigger events in Kalipso.
     */
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalScannerAPIException {
        //Use this variable to send Barcode Scan events back to Kalipso
        //For example calling mEventsInterface.BarcodeScanned("barcodeString", barcodeType, "userParameter");
        mEventsInterface = eventsInterface;
        eventsInterface.AddOnAppEventListener(this);

        //Add your Barcode initialization code here
        this.act = act;
        macAddress = userParameters;
        if (btReader.init(ctx)) {
            checkReadWritePermission();
            checkBluetooth();
            checkLocation();
            btReader.setBeep(true);
            Log.e("KT1Connect", String.valueOf(btReader.getConnectStatus()));
            if (btReader.getConnectStatus() == ConnectionStatus.DISCONNECTED) {
                btReader.connect(macAddress, btStatus);
            }
        } else throw new KExternalScannerAPIException();

        btReader.setKeyEventCallback(new KeyEventCallback() {
            @Override
            public void onKeyDown(int keyCode) {
                Log.e("KT1KeyDown", "KT1KeyDown");
                if (isEnabled || !isTrigger) scan();
            }

            @Override
            public void onKeyUp(int keyCode) {
            }
        });
    }

    /**
     * Called to disconnect from the barcode scanner
     *
      * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void Disconnect(Context ctx, String userParameters) {
        if (btReader.getConnectStatus() == ConnectionStatus.CONNECTED) {
            if (btReader.free()) {
                btReader.disconnect();
                Log.e("KT1Disconnect", String.valueOf(btReader.getConnectStatus()));
            }
        }
        if (mEventsInterface != null) {
            mEventsInterface.RemoveOnAppEventListener(this);
            mEventsInterface = null;
        }
    }

    /**
     * Called to enabled/disable the scanner
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param enabled        indicates to enable or disable the scanner
     * @param userParameters Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabled(Context ctx, boolean enabled, String userParameters) throws KExternalScannerAPIException {
        if (enabled) isEnabled = true;
        else isEnabled = false;
    }

    /**
     * Called to wait for a barcode scan. Add the results to the Lists of scannedBarcodes and types to the list of scannedBarcodeTypes
     *
     * @param ctx                 Current context. It may be required by the implementation.
     * @param timeOut             Maximum time in milliseconds to wait for the sacnner
     * @param softTrigger         If true, scanning will begin immediately by using a software trigger.
     *                            If false the user has to press the scan button to start scanning
     * @param scannedBarcodes     When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param scannedBarcodeTypes When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param userParameters      Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void ScanBarcode(Context ctx, int timeOut, boolean softTrigger, ArrayList<String> scannedBarcodes, ArrayList<String> scannedBarcodeTypes, String userParameters) throws KExternalScannerAPIException {
        isEvent = false;
        this.scannedBarcodes = scannedBarcodes;
        this.scannedBarcodeTypes = scannedBarcodeTypes;
        if (btReader.getConnectStatus() == ConnectionStatus.CONNECTED) {
            isTrigger = softTrigger;
            if (softTrigger) {
                data = btReader.scanBarcode();
                if (data == null) throw new KExternalScannerAPIException("No data found!");
                Log.e("KT1Data", data);
                scannedBarcodes.add(data);
                scannedBarcodeTypes.add("0");
            } else {
                synchronized (waiter) {
                    try {
                        waiter.wait();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        } else throw new KExternalScannerAPIException("Not connected!");
        isEvent = true;
    }

    /**
     * Called to set the enabled symbologies
     *
     * @param ctx              Current context. It may be required by the implementation.
     * @param symbologiesList  list of symbologies to enable with Kalipso IDs. You will need to convert to the scanner IDs
     * @param symbologiesCount number of entries in symbologiesList array
     * @param userParameters   Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabledSymbologies(Context ctx, int[] symbologiesList, int symbologiesCount, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("Not implemented");
    }

    /**
     * Called to get the enabled symbologies
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param symbologiesList When called this will be an empty list, on return should have the list of enabled symbologies with Kalipso IDs. You will need to convert from the scanner IDs
     * @param userParameters  Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void GetEnabledSymbologies(Context ctx, ArrayList<Integer> symbologiesList, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("Not implemented");
    }

    //************************ Events reported from Kalipso through KExternalEventsHandler
    @Override
    public void onAppPaused(Context ctx) {
        if (btReader.getConnectStatus() == ConnectionStatus.CONNECTED) {
            btReader.disconnect();
        }
        if (mEventsInterface != null) {
            mEventsInterface.RemoveOnAppEventListener(this);
            mEventsInterface = null;
        }
    }

    @Override
    public void onAppResumed(Context ctx) {
        if (btReader.getConnectStatus() == ConnectionStatus.DISCONNECTED) {
            btReader.connect(macAddress);
        }
        mEventsInterface.AddOnAppEventListener(this);
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event) {
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event) {
    }

    class BTStatus implements ConnectionStatusCallback<Object> {
        @Override
        public void getStatus(final ConnectionStatus connectionStatus, final Object device1) {
            act.runOnUiThread(() -> {
                btDevice = (BluetoothDevice) device1;
                String remoteBTName;
                String remoteBTAdd;
                Log.e("KT1Status", String.valueOf(connectionStatus));
                if (connectionStatus == ConnectionStatus.CONNECTED) {
                    remoteBTName = btDevice.getName();
                    remoteBTAdd = btDevice.getAddress();
                    Log.e("KT1CONNECTED", ConnectionStatus.CONNECTED + " - " + remoteBTName + " | " + remoteBTAdd);
                }
            });
        }
    }

    private synchronized void scan() {
        data = null;
        if (!isRunning) {
            isRunning = true;
            new ScanThread().start();
        }
    }

    class ScanThread extends Thread {
        public void run() {
            while (isRunning) {
                String data = btReader.scanBarcode();
                if (data != null && !data.isEmpty()) {
                    Log.e("KT1Data2", data);
                    if (!isEvent) {
                        scannedBarcodes.add(data);
                        scannedBarcodeTypes.add("0");
                    } else mEventsInterface.BarcodeScanned(data, 0, "");
                    isRunning = false;
                    if (waiter != null) {
                        synchronized (waiter) {
                            waiter.notify();
                        }
                    }
                }
                isRunning = false;
            }
        }
    }

    private void checkBluetooth() throws KExternalScannerAPIException {
        BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
        if (btAdapter == null)
            throw new KExternalScannerAPIException("Device does not support Bluetooth!");
        Log.d("KT1isBluetooth", String.valueOf(btAdapter.isEnabled()));
        if (!btAdapter.isEnabled()) {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            act.startActivityForResult(intent, REQUEST_ENABLE_BT);
        }
    }

    private void checkLocation() throws KExternalScannerAPIException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (act.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Boolean isFine = mEventsInterface.RequestAndroidPermission(android.Manifest.permission.ACCESS_FINE_LOCATION);
                Log.d("KT1isFineLocation", String.valueOf(isFine));
                if (!isFine) throw new KExternalScannerAPIException("Permission denied!");
            }
        }
        Log.d("KT1isLocation", String.valueOf(isLocation()));
        if (!isLocation()) {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            act.startActivityForResult(intent, REQUEST_ACTION_LOCATION_SETTINGS);
        }
    }

    private boolean isLocation() {
        int locationMode;
        String locationProviders;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                locationMode = Settings.Secure.getInt(act.getContentResolver(), Settings.Secure.LOCATION_MODE);
            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
                return false;
            }
            return locationMode != Settings.Secure.LOCATION_MODE_OFF;
        } else {
            locationProviders = Settings.Secure.getString(act.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
            return !TextUtils.isEmpty(locationProviders);
        }
    }

    private void checkReadWritePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                act.startActivityForResult(intent, ALL_FILES_ACCESS_PERMISSION);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (act.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                mEventsInterface.RequestAndroidPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (act.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                mEventsInterface.RequestAndroidPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }
    }
}