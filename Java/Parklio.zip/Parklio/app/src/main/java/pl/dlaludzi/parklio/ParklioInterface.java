package pl.dlaludzi.parklio;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;

import com.parklio.library2.ParklioDevice;
import com.parklio.library2.ParklioDeviceCallback;
import com.parklio.library2.ParklioDeviceFactory;
import com.parklio.library2.comm.callback.FailCallback;
import com.parklio.library2.comm.callback.OperationCallback;
import com.parklio.library2.error.ErrorCode;
import com.parklio.library2.status.DeviceStatus;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;

public class ParklioInterface {

    private static Handler parklioEventHandler = null;
    private static final Object LOCK = new Object();
    private static boolean commandInProgress=false;
    private static KExternalEventsInterface kalipsoEventsInterface = null;
    private static final ParklioDeviceCallback parklioCallback = new ParklioDeviceCallback()
    {
        @Override
        public void onConnected() {
            if(kalipsoEventsInterface!=null)
            {
                String []tVars = new String[100];
                tVars[0]="Device_Connected";
                kalipsoEventsInterface.NotifyAllForms(tVars);
            }
        }

        @Override
        public void onDisconnected() {
            if(kalipsoEventsInterface!=null)
            {
                String []tVars = new String[100];
                tVars[0]="Device_Disconnected";
                kalipsoEventsInterface.NotifyAllForms(tVars);
            }
        }

        @Override
        public void onReady() {
            if(kalipsoEventsInterface!=null)
            {
                String []tVars = new String[100];
                tVars[0]="Device_Ready";
                kalipsoEventsInterface.NotifyAllForms(tVars);
            }
        }

        @Override
        public void onError(ErrorCode error) {
            if(kalipsoEventsInterface!=null)
            {
                String []tVars = new String[100];
                tVars[0]="Device_Error";
                tVars[1]=String.valueOf(error.code());
                tVars[2]=error.name();
                kalipsoEventsInterface.NotifyAllForms(tVars);
            }
        }

        @Override
        public void onDeviceStatusReceived(DeviceStatus status) {
            if(kalipsoEventsInterface!=null)
            {
                String []tVars = new String[100];
                tVars[0]="Device_Status";
                tVars[1]=status.getType().name();
                tVars[2]=status.getPosition().name();
                kalipsoEventsInterface.NotifyAllForms(tVars);
            }
        }
    };

    private static ParklioDevice parklioDevice = null;

    public static void Connect(Activity act, KExternalEventsInterface eventsInterface, String guestKey) throws Exception
    {
        Disconnect();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            eventsInterface.RequestAndroidPermission(android.Manifest.permission.BLUETOOTH_SCAN);
            eventsInterface.RequestAndroidPermission(android.Manifest.permission.BLUETOOTH_CONNECT);
        } else {
            eventsInterface.RequestAndroidPermission(android.Manifest.permission.ACCESS_FINE_LOCATION);
        }

        parklioEventHandler = new Handler(act.getMainLooper());

        parklioDevice = ParklioDeviceFactory.create(act.getApplicationContext(), guestKey, parklioCallback, parklioEventHandler);

        kalipsoEventsInterface = eventsInterface;

        if( !parklioDevice.isConnected() ) {
            boolean success = parklioDevice.connect().enqueue();

            /* If there is no space in the queue the enqueue() method returns false. */
            if( !success ) {
                throw new Exception("Unable to enqueue connection request");
            }
        } else  {
            //already connected
        }
    }

    public static void Disconnect() throws Exception
    {
        if(kalipsoEventsInterface!=null)
            kalipsoEventsInterface=null;

        if(parklioEventHandler!=null) {
            parklioEventHandler.removeCallbacks(null);
            parklioEventHandler=null;
        }

        /* The application MUST close the ParklioDevice instance to avoid memory leaks and dangling threads */
        if(parklioDevice!=null) {
            parklioDevice.disconnect().enqueue();
            parklioDevice.close();
            parklioDevice=null;
        }
    }

    public static void OpenDevice() throws Exception
    {
        if(parklioDevice==null)
            throw new Exception("Not connected to device");

        parklioDevice.waitReady()
                .onSuccess(() -> {
                    synchronized ( LOCK ) {
                        if (!commandInProgress) {
                            commandInProgress = true;

                            parklioDevice.openDevice()
                                    .setOperationCallback(new OperationCallback() {
                                        @Override
                                        public void onOperationComplete(DeviceStatus status) {
                                            if(kalipsoEventsInterface!=null)
                                            {
                                                String []tVars = new String[100];
                                                tVars[0]="Device_Open_OK";
                                                tVars[1]=String.valueOf(status.getType().name());
                                                tVars[2]=status.getPosition().name();
                                                kalipsoEventsInterface.NotifyAllForms(tVars);
                                            }
                                        }
                                    })
                                    .before(() -> {
                                        //Log.d(TAG, "Close device.");
                                    })
                                    .onFail(new FailCallback() {
                                        @Override
                                        public void onRequestFailed(ErrorCode errorCode) {
                                            if(kalipsoEventsInterface!=null)
                                            {
                                                String []tVars = new String[100];
                                                tVars[0]="Device_Open_Error";
                                                tVars[1]=String.valueOf(errorCode.code());
                                                tVars[2]=errorCode.name();
                                                kalipsoEventsInterface.NotifyAllForms(tVars);
                                            }
                                        }
                                    })
                                    .then(() -> { synchronized (LOCK) { commandInProgress = false; }})
                                    .enqueue();

                            /*
                             * If not ready just log it.
                             * In the end application you may wish to disable other actions while there is an operation
                             * in progress.
                             */
                        } else {
                            //Log.w(TAG, "Another operation is already in progress.");
                        }
                    }
                })
                .onFail(errorCode -> {
                    //Log.w(TAG, "Could not refresh. Device not ready!");
                })
                .enqueue();
    }

    public static void CloseDevice() throws Exception
    {
        if(parklioDevice==null)
            throw new Exception("Not connected to device");

        parklioDevice.waitReady()
            .onSuccess(() -> {
                synchronized ( LOCK ) {
                    if (!commandInProgress) {
                        commandInProgress = true;

                        parklioDevice.closeDevice()
                                .setOperationCallback(new OperationCallback() {
                                    @Override
                                    public void onOperationComplete(DeviceStatus status) {
                                        if(kalipsoEventsInterface!=null)
                                        {
                                            String []tVars = new String[100];
                                            tVars[0]="Device_Close_OK";
                                            tVars[1]=String.valueOf(status.getType().name());
                                            tVars[2]=status.getPosition().name();
                                            kalipsoEventsInterface.NotifyAllForms(tVars);
                                        }
                                    }
                                })
                                .before(() -> {
                                    //Log.d(TAG, "Close device.");
                                })
                                .onFail(new FailCallback() {
                                    @Override
                                    public void onRequestFailed(ErrorCode errorCode) {
                                        if(kalipsoEventsInterface!=null)
                                        {
                                            String []tVars = new String[100];
                                            tVars[0]="Device_Close_Error";
                                            tVars[1]=String.valueOf(errorCode.code());
                                            tVars[2]=errorCode.name();
                                            kalipsoEventsInterface.NotifyAllForms(tVars);
                                        }
                                    }
                                })
                                .then(() -> { synchronized (LOCK) { commandInProgress = false; }})
                                .enqueue();

                        /*
                         * If not ready just log it.
                         * In the end application you may wish to disable other actions while there is an operation
                         * in progress.
                         */
                    } else {
                        //Log.w(TAG, "Another operation is already in progress.");
                    }
                }
            })
            .onFail(errorCode -> {
                //Log.w(TAG, "Could not refresh. Device not ready!");
            })
            .enqueue();
    }
}
