package com.sysdevmobile.keyencescanplugin;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.KeyEvent;
import com.keyence.autoid.sdk.SdkStatus;
import com.keyence.autoid.sdk.scan.DecodeResult;
import com.keyence.autoid.sdk.scan.ScanManager;
import com.keyence.autoid.sdk.scan.scanparams.CodeType;
import com.keyence.autoid.sdk.scan.scanparams.DataOutput;
import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPIException;

import java.util.ArrayList;

public class ScanInterface extends KExternalEventsHandler implements KExternalScannerAPI, ScanManager.DataListener {
    private KExternalEventsInterface mEventsInterface = null;
    private ScanManager mScanManager = null;
    private Object waiter = null;
    private DataOutput dataOutput = null;
    private boolean defWedge, isEnabled, isScanAction;
    private String onData;
    private int onType;
    private DecodeResult.Result onRes;

    //************************ Implementation of Kalipso Barcode actions

    /**
     * Called to Connect to the barcode scanner
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param act             Current activity. It may be required by the implementation.
     * @param connectionType  The type of connection with the RFID device
     * @param address         The address of the RFID device.
     *                        For Bluetooth is the device MC address
     *                        For Socket is the IP or name
     *                        For Serial is the device string
     * @param userParameters  User parameters
     * @param eventsInterface Interface so you can trigger events in Kalipso.
     */
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalScannerAPIException {
        //Use this variable to send Barcode Scan events back to Kalipso
        //For example calling mEventsInterface.BarcodeScanned("barcodeString", barcodeType, "userParameter");
        mEventsInterface = eventsInterface;
        mEventsInterface.AddOnAppEventListener(this);
        dataOutput = new DataOutput();
        waiter = new Object();

        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //Add your Barcode initialization code here
                mScanManager = ScanManager.createScanManager(ctx);
                mScanManager.getConfig(dataOutput);

                Log.d("KT1Getconfig", String.valueOf(mScanManager.getConfig(dataOutput)));
                Log.d("KT1DefWedge", String.valueOf(dataOutput.keyStrokeOutput.enabled));

                //Save terminal's wedge settings for later
                defWedge = dataOutput.keyStrokeOutput.enabled;

                dataOutput.keyStrokeOutput.enabled = false;
                mScanManager.setConfig(dataOutput);

                Log.d("KT1Setconfig", String.valueOf(mScanManager.setConfig(dataOutput)));

                mScanManager.addDataListener(ScanInterface.this);
                synchronized (waiter) {
                    waiter.notify();
                }
            }
        });

        synchronized (waiter) {
            try {
                waiter.wait(); // unlocks myRunable while waiting
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        if (mScanManager == null) {
            throw new KExternalScannerAPIException(errorStatus(mScanManager.toString()));
        }
        isEnabled = false;
        mScanManager.lockScanner();
    }


    /**
     * Called to disconnect from the barcode scanner
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalScannerAPIException {
        mScanManager.getConfig(dataOutput);
        Log.d("KT1GetconfigDC", String.valueOf(mScanManager.getConfig(dataOutput)));
        dataOutput.keyStrokeOutput.enabled = defWedge;
        Log.d("KT1defWedgeDC", String.valueOf(defWedge));
        mScanManager.setConfig(dataOutput);
        Log.d("KT1SetconfigDC", String.valueOf(mScanManager.setConfig(dataOutput)));
        mScanManager.removeDataListener(this);
        mScanManager.releaseScanManager();

        if (mScanManager == null) {
            throw new KExternalScannerAPIException("SDKError:NULL");
        }
    }


    /**
     * Called to enabled/disable the scanner
     *
     * @param ctx            Current context. It may be required by the implementation.
     * @param enabled        indicates to enable or disable the scanner
     * @param userParameters Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabled(Context ctx, boolean enabled, String userParameters) throws KExternalScannerAPIException {
        if (enabled) {
            mScanManager.unlockScanner();
        } else {
            mScanManager.lockScanner();
        }

        isEnabled = enabled;

        if (mScanManager == null) {
            throw new KExternalScannerAPIException("SDKError:NULL");
        }
    }

    /**
     * Called to wait for a barcode scan. Add the results to the Lists of scannedBarcodes and types to the list of scannedBarcodeTypes
     *
     * @param ctx                 Current context. It may be required by the implementation.
     * @param timeOut             Maximum time in milliseconds to wait for the sacnner
     * @param softTrigger         If true, scanning will begin immediately by using a software trigger.
     *                            If false the user has to press the scan button to start scanning
     * @param scannedBarcodes     When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param scannedBarcodeTypes When called this will be an empty list, on return should have the scanned barcode.
     *                            If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     * @param userParameters      Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void ScanBarcode(Context ctx, int timeOut, boolean softTrigger, ArrayList<String> scannedBarcodes, ArrayList<String> scannedBarcodeTypes, String userParameters) throws KExternalScannerAPIException {
        isScanAction = true;
        onRes = DecodeResult.Result.CANCELED;
        boolean wasEnabled = isEnabled;
        if(!wasEnabled)
            SetEnabled(ctx, true, "");
        if(softTrigger) {
            mScanManager.startRead();
        }
        synchronized (waiter) {
            try {
                waiter.wait(timeOut); // unlocks myRunable while waiting

                if (softTrigger) mScanManager.stopRead();

                if (onRes == DecodeResult.Result.SUCCESS) {
                    scannedBarcodes.add(onData);
                    scannedBarcodeTypes.add(String.valueOf(onType));
                    isScanAction = false;
                    Log.d("KT1dataButton", onData);
                } else {
                    Log.d("KT1err",onRes.toString());
                    isScanAction = false;
                    throw new KExternalScannerAPIException("Scan timeout!");

                }
            } catch (InterruptedException e) {
                if(!wasEnabled)
                    SetEnabled(ctx, false, "");
                throw new RuntimeException(e);
            }
        }
        if(!wasEnabled)
            SetEnabled(ctx, false, "");
    }


    /**
     * Called to set the enabled symbologies
     *
     * @param ctx              Current context. It may be required by the implementation.
     * @param symbologiesList  list of symbologies to enable with Kalipso IDs. You will need to convert to the scanner IDs
     * @param symbologiesCount number of entries in symbologiesList array
     * @param userParameters   Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabledSymbologies(Context ctx, int[] symbologiesList, int symbologiesCount, String userParameters) throws KExternalScannerAPIException {
        boolean wasEnabled = isEnabled;
        if (!wasEnabled) {
            SetEnabled(ctx, true, "");
        }

        CodeType codeType = new CodeType();
        mScanManager.getConfig(codeType);
        codeType.setAllDisable();
        for (int i : symbologiesList) {
            switch (i) {
                case 1:
                    codeType.upcEanJan = true;
                    break;
                case 23:
                    codeType.code128 = true;
                    break;
                case 13:
                    codeType.code39 = true;
                    break;
                case 15:
                    codeType.itf = true;
                    break;
                case 37:
                    codeType.gs1DataBar = true;
                    break;
                case 40:
                    codeType.datamatrix = true;
                    break;
                case 41:
                    codeType.qrCode = true;
                    break;
                case 33:
                    codeType.pdf417 = true;
                    break;
                case 101:
                    codeType.industrial2Of5 = true;
                    break;
                case 19:
                    codeType.codabarNw7 = true;
                    break;
                case -1:
                    codeType.coop2Of5 = true;
                    break;
                case 25:
                    codeType.code93 = true;
                    break;
                case 43:
                    codeType.compositeAb_Gs1Databar = true;
                    break;
                case 47:
                    codeType.compositeAb_EanUpc = true;
                    break;
                case 46:
                    codeType.composite_Gs1_128 = true;
                    break;
                case 66:
                    codeType.postal = true;
                    break;
                case -2:
                    codeType.ocr = true;
                    break;
            }
        }

        mScanManager.setConfig(codeType);

        if (mScanManager.setConfig(codeType) != SdkStatus.SUCCESS) {
            throw new KExternalScannerAPIException(errorStatus(mScanManager.setConfig(codeType).toString()));
        }

        if (!wasEnabled) {
            SetEnabled(ctx, false, "");
        }
    }


    //Called to get the enabled symbologies. They should be returned in symbologiesList[] and the function result should be the number of symbologies passed in symbologiesList[]

    /**
     * Called to get the enabled symbologies
     *
     * @param ctx             Current context. It may be required by the implementation.
     * @param symbologiesList When called this will be an empty list, on return should have the list of enabled symbologies with Kalipso IDs. You will need to convert from the scanner IDs
     * @param userParameters  Generic parameters to use as you want.
     * @return Should return 0 for false or 1 for true
     * but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void GetEnabledSymbologies(Context ctx, ArrayList<Integer> symbologiesList, String userParameters) throws KExternalScannerAPIException {
        // Define a variable to store the code type.
        CodeType codeType = new CodeType();
        // Acquire the current setting values.
        mScanManager.getConfig(codeType);

        if (codeType.upcEanJan) symbologiesList.add(code2Num("UPC/EAN/JAN"));
        if (codeType.code128) symbologiesList.add(code2Num("Code128"));
        if (codeType.code39) symbologiesList.add(code2Num("Code39"));
        if (codeType.itf) symbologiesList.add(code2Num("ITF"));
        if (codeType.gs1DataBar) symbologiesList.add(code2Num("GS1 DataBar"));
        if (codeType.datamatrix) symbologiesList.add(code2Num("Datamatrix"));
        if (codeType.qrCode) symbologiesList.add(code2Num("QRCode"));
        if (codeType.pdf417) symbologiesList.add(code2Num("PDF417"));
        if (codeType.industrial2Of5) symbologiesList.add(code2Num("Industrial 2of5"));
        if (codeType.codabarNw7) symbologiesList.add(code2Num("Codabar(NW7)"));
        if (codeType.coop2Of5) symbologiesList.add(code2Num("COOP2of5"));
        if (codeType.code93) symbologiesList.add(code2Num("Code93"));
        if (codeType.compositeAb_Gs1Databar)
            symbologiesList.add(code2Num("Composite AB(GS1-Databar)"));
        if (codeType.compositeAb_EanUpc) symbologiesList.add(code2Num("Composite AB(EAN/UPC)"));
        if (codeType.composite_Gs1_128) symbologiesList.add(code2Num("Composite (GS1-128)"));
        if (codeType.postal) symbologiesList.add(code2Num("Postal"));
        if (codeType.ocr) symbologiesList.add(code2Num("Ocr"));

        Log.d("KT1codeType", symbologiesList.toString());

        if (mScanManager.getConfig(codeType) != SdkStatus.SUCCESS) {
            throw new KExternalScannerAPIException(errorStatus(mScanManager.getConfig(codeType).toString()));
        }
    }


    //************************ Events reported from Kalipso through KExternalEventsHandler
    @Override
    public void onAppPaused(Context ctx) {
        super.onAppPaused(ctx);
        dataOutput.keyStrokeOutput.enabled = defWedge;
        //mScanManager.getConfig(dataOutput);
        mScanManager.setConfig(dataOutput);
        mScanManager.removeDataListener(this);
        mScanManager.unlockScanner();
        Log.d("KT1Pause", mScanManager.removeDataListener(ScanInterface.this).toString());
    }

    @Override
    public void onAppResumed(Context ctx) {
        super.onAppResumed(ctx);
        dataOutput.keyStrokeOutput.enabled = false;
        mScanManager.setConfig(dataOutput);
        if(isEnabled)
            mScanManager.unlockScanner();
        else
            mScanManager.lockScanner();
        mScanManager.addDataListener(this);
        Log.d("KT1Resume", mScanManager.addDataListener(ScanInterface.this).toString());
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event) {
        //Log.d("KT1KeyDown", String.valueOf(keyCode));
        if (keyCode == 305) mEventsInterface.ScannerTriggerPressed();
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event) {
        //Log.d("KT1KeyUp", String.valueOf(keyCode));
        if (keyCode == 305) mEventsInterface.ScannerTriggerReleased();
    }

    // Create a read event
    @Override
    public void onDataReceived(DecodeResult decodeResult) {
        // Acquire the reading result.
        DecodeResult.Result result = decodeResult.getResult();
        Log.d("KT1Res", String.valueOf(result));
        onRes = result;
        if (result == DecodeResult.Result.SUCCESS) {
            // Acquire the read code type.
            String codeType = decodeResult.getCodeType();
            // Acquire the read data.
            String data = decodeResult.getData();
            if (isScanAction) {
                onData = data;
                onType = code2Num(codeType);
            } else mEventsInterface.BarcodeScanned(data, code2Num(codeType), "");
        }
        synchronized (waiter) {
            waiter.notify();
        }
    }

    private int code2Num(String codeType) {
        int res;
        switch (codeType) {
            case "UPC/EAN/JAN":
                res = 1;
                break;
            case "Code128":
                res = 23;
                break;
            case "Code39":
                res = 13;
                break;
            case "ITF":
                res = 15;
                break;
            case "GS1 DataBar":
                res = 37;
                break;
            case "Datamatrix":
                res = 40;
                break;
            case "QRCode":
                res = 41;
                break;
            case "PDF417":
                res = 33;
                break;
            case "Industrial 2of5":
                res = 101;
                break;
            case "Codabar(NW7)":
                res = 19;
                break;
            case "COOP2of5":
                res = -1;
                break;
            case "Code93":
                res = 25;
                break;
            case "Composite AB(GS1-Databar)":
                res = 43;
                break;
            case "Composite AB(EAN/UPC)":
                res = 47;
                break;
            case "Composite (GS1-128)":
                res = 46;
                break;
            case "Postal":
                res = 66;
                break;
            case "Ocr":
                res = -2;
                break;
            default:
                res = 0;
                break;
        }
        return res;
    }

    private String errorStatus(String status) {
        String res = "";
        switch (status) {
            case "SUCCESS":
                res = "Process success";
                break;
            case "FAIL":
                res = "Process failure";
                break;
            case "INVALID_PARAM":
                res = "Error: Invalid parameter";
                break;
            case "ALREADY_EXIST ":
                res = "Error: Already exists";
                break;
            case "NOT_PERMIT":
                res = "Error: Not permitted";
                break;
            case "NOT_SUPPORT":
                res = "Error: Not supported";
                break;
        }
        return res;
    }
}