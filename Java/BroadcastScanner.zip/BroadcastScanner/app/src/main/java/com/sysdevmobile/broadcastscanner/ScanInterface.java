package com.sysdevmobile.broadcastscanner;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.KeyEvent;

import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPIException;

import java.util.ArrayList;

public class ScanInterface extends KExternalEventsHandler implements KExternalScannerAPI {
    private Context mMainCtx = null;
    private KExternalEventsInterface mEventsInterface = null;
    BroadcastReceiver mReceiver = null;


    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalScannerAPIException {
        mMainCtx = ctx;
        mEventsInterface = eventsInterface;

        //This call is optional.
        //Call if you wan to handle the events from KExternalEventsHandler onAppPaused(), onAppResumed(), onKeyDown(), onKeyUp()
        eventsInterface.AddOnAppEventListener(this);
    }

    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalScannerAPIException {
        if(mReceiver != null) {
            if(mMainCtx!=null)
                mMainCtx.unregisterReceiver(mReceiver);
            mReceiver = null;
        }

        mMainCtx = null;
        mEventsInterface = null;
    }

    @Override
    public void SetEnabled(Context ctx, boolean enabled, String userParameters) throws KExternalScannerAPIException {
        if(mMainCtx==null)
            throw new KExternalScannerAPIException("Not connected!\r\nCall BarcodeConnect() first.");

        if(enabled) {
            if(mReceiver == null) {
                mReceiver = new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        String barcodeReceived = "";
                        int barcodeSymbology = 0;
                        String userData = "";

                        //TODO: Code to handle the broadcast, these 2 lines of code are dummy
                        barcodeReceived = "1234567890";
                        barcodeSymbology = 13;//Code 39

                        //Send BarcodeScanned event to Kalipso
                        if(mEventsInterface!=null)
                            mEventsInterface.BarcodeScanned(barcodeReceived, barcodeSymbology, userData);
                    }
                };

                //TODO: Create a correct IntentFilter
                IntentFilter filter = new IntentFilter("ENTER ACTION TO USE");
                mMainCtx.registerReceiver(mReceiver, filter);
            }
        }
        else {
            if(mReceiver != null) {
                mMainCtx.unregisterReceiver(mReceiver);
                mReceiver = null;
            }
        }
    }

    @Override
    public void ScanBarcode(Context ctx, int timeOut, boolean softTrigger, ArrayList<String> scannedBarcodes, ArrayList<String> scannedBarcodeTypes, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("ScanBarcode is not implemented");
    }

    @Override
    public void SetEnabledSymbologies(Context ctx, int[] symbologiesList, int symbologiesCount, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("SetEnabledSymbologies is not implemented");
    }

    @Override
    public void GetEnabledSymbologies(Context ctx, ArrayList<Integer> symbologiesList, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("GetEnabledSymbologies is not implemented");
    }


    @Override
    public void onAppPaused(Context ctx)
    {
    }

    @Override
    public void onAppResumed(Context ctx)
    {
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event) {
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event) {
    }
}
